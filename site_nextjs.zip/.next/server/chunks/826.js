"use strict";
exports.id = 826;
exports.ids = [826];
exports.modules = {

/***/ 2758:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ component_CardProduct)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./component/atoms/Like.jsx
var Like = __webpack_require__(925);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./component/molecules/familyProduct.jsx




const FamilyProduct = ({ familyProduct , idDad , codeDad  })=>{
    const { 0: animate , 1: setAnimate  } = (0,external_react_.useState)("animete");
    const delteAnimateLoad = ()=>{
        setAnimate("");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "familyProduct",
        children: [
            familyProduct.map((product, i)=>{
                if (i <= 3) {
                    return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/articulo/${idDad}/${product.codigo}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: animate,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                width: 40,
                                height: 40,
                                onLoadingComplete: delteAnimateLoad,
                                objectFit: "contain",
                                src: product.image[0],
                                alt: product.name
                            })
                        })
                    }, i);
                }
            }),
            familyProduct.length > 1 && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: `/articulo/${idDad}/${codeDad}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: "mw-flex-column cart-color",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "cart-length-color",
                            children: [
                                " ",
                                familyProduct.length,
                                " "
                            ]
                        }),
                        "  colores"
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const molecules_familyProduct = (FamilyProduct);

;// CONCATENATED MODULE: ./component/CardProduct.jsx







const CardProduct = ({ id , code , name , costo , idDad , descuento , image , typeUser , familyProduct , idx  })=>{
    const { 0: animate , 1: setAnimate  } = (0,external_react_.useState)("animete");
    const delteAnimateLoad = ()=>{
        setAnimate("");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "box-card",
        children: [
            typeUser != 1 ? /*#__PURE__*/ jsx_runtime_.jsx(Like/* default */.Z, {
                css: "img-card-like",
                id: id,
                codigo: code,
                idDad: idDad,
                name: name,
                descuento: descuento,
                cost: costo,
                image: image
            }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card-product",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/articulo/${id}/${code}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: `cart-img ${animate}`,
                                children: idx < 4 ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: image,
                                        alt: name,
                                        layout: "fill",
                                        priority: true,
                                        onLoadingComplete: delteAnimateLoad,
                                        className: "cart-img-img"
                                    })
                                }) : /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: image,
                                    alt: name,
                                    layout: "fill",
                                    onLoadingComplete: delteAnimateLoad,
                                    className: "cart-img-img"
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(molecules_familyProduct, {
                        familyProduct: familyProduct,
                        idDad: id,
                        codeDad: code
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/articulo/${id}/${code}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "card-description",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        children: name || "titulo de prueba de los articulos publicados"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: descuento > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "box-price-cart-ofert",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "price-cart price-cart-ofert",
                                                        children: [
                                                            "S/ ",
                                                            costo,
                                                            ",",
                                                            /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                                children: "00"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "price-cart",
                                                    children: [
                                                        "S/ ",
                                                        costo - descuento,
                                                        ",",
                                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                            children: "00"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "price-cart",
                                            children: [
                                                "S/ ",
                                                costo,
                                                ",",
                                                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                    children: "00"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
};
const mapStateToProps = (state)=>({
        typeUser: state.userReducer.type
    });
/* harmony default export */ const component_CardProduct = ((0,external_react_redux_.connect)(mapStateToProps)(CardProduct));


/***/ }),

/***/ 1514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YP": () => (/* binding */ none),
/* harmony export */   "po": () => (/* binding */ loadImage),
/* harmony export */   "tA": () => (/* binding */ toShow)
/* harmony export */ });
const loadImage = (e)=>e.target.style.opacity = "1";
/** Muestra cualquier elemento
 * @param element elemento a mostrar
 * @param display tipo de display css para mostrar el elemento
 */ const toShow = (element, display)=>{
    if (display) element.style.display = display;
    else element.classList.toggle("toShow");
};
/** Oculta cualquier elemento
* @param element elemento que se ocultara 
*/ const none = (element)=>{
    if (element.classList.contains("toShow")) element.classList.toggle("toShow");
    else element.style.display = "none";
};


/***/ })

};
;