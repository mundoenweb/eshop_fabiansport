"use strict";
exports.id = 6091;
exports.ids = [6091];
exports.modules = {

/***/ 5647:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const AlertSpan = ({ referencia , color , center , none  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        ref: referencia,
        className: `${none} alert alert-${color} ${center}`
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AlertSpan);


/***/ }),

/***/ 8560:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const InputEmail = ({ labelText , name , required , validateType  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
        children: [
            labelText || "Correo",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "text",
                name: name || "email",
                className: `${required === false ? "" : "required"} ${validateType && validateType}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "msgAlertForm"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputEmail);


/***/ }),

/***/ 5900:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ handleStartSesionEmail),
/* harmony export */   "r": () => (/* binding */ handleRegisClient)
/* harmony export */ });
/* harmony import */ var _redux_actionCreators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2196);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useValidetForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2001);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3619);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);





const api = "https://apinode.fabiansport.com";
let response = null;
//inicia sesion por medio de correo electronico
const handleStartSesionEmail = (e, err, router)=>{
    e.preventDefault();
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().start();
    const form = e.target;
    const formData = new FormData(form);
    let href = router.query.path;
    // validando formulario
    if (!err.current.classList.contains("none")) {
        err.current.innerText = "";
        err.current.classList.toggle("none");
    }
    if (form.email.value !== "rommer") {
        if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_4__/* .validateForm */ .G)(form)) return nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
    }
    // realizando peticion de logged
    axios__WEBPACK_IMPORTED_MODULE_3___default().post(`${api}/logged`, formData).then((res)=>{
        const data = res.data.data;
        compareLikesServer(data.user.id, data.token);
        getDataDelivey(data.user.id, data.token);
        getInvoiceDetailData(data.user.id, data.token);
        redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_0__/* .startSesion */ .PQ)(data));
        if (data.user.role === 1) {
            router.push(href || "/app/admin/productos");
            return;
        }
        router.push(href || "/productos/todos");
    }).catch((error)=>{
        const msgErro = error.response.data.message;
        err.current.innerText = msgErro;
        if (err.current.classList.contains("none")) err.current.classList.toggle("none");
    }).then(()=>nprogress__WEBPACK_IMPORTED_MODULE_1___default().done());
};
//registra un nuevo cliente mediante correo electronico en la db y actualiza el estado global
const handleRegisClient = async (e, error, router)=>{
    e.preventDefault();
    const form = e.target;
    const formData = new FormData();
    let href = router.query.path;
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_4__/* .validateForm */ .G)(form)) return;
    if (form.password.value !== form.passwordTwo.value) {
        error.current.innerText = "Las contrase\xf1as no son iguales";
        if (error.current.classList.contains("none")) error.current.classList.toggle("none");
        return;
    }
    formData.append("email", form.email.value);
    formData.append("password", form.password.value);
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().start();
    axios__WEBPACK_IMPORTED_MODULE_3___default().post(`${api}/users`, formData).then((response)=>{
        const data = response.data.data;
        compareLikesServer(data.user.id, data.token);
        redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_0__/* .startSesion */ .PQ)(data));
        router.push(href || "/productos/todos");
    }).catch((err)=>{
        const error = err.response.data;
        console.log(error);
        if (error.errno === 1062) alert(`el correo ${form.email.value} ya existe`);
    }).then(()=>{
        nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
    });
};
const compareLikesServer = (idUser, token)=>{
    const options = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    axios__WEBPACK_IMPORTED_MODULE_3___default().get(`${api}/likes/${idUser}`, options).then((response)=>{
        const likesDB = response.data.data;
        const likesStore = redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getState */ .Z.getState().likeReducer.products;
        if (likesDB.length) {
            let likes;
            if (likesStore.length) {
                likes = likesStore.filter((like)=>{
                    const same = likesDB.find((likeDB)=>likeDB.id_producto == like.id_producto);
                    if (!same) return like;
                });
            } else likes = likesStore;
            for (const like of likes){
                if (!like.id_usuario) like.id_usuario = idUser;
                axios__WEBPACK_IMPORTED_MODULE_3___default().post(`${api}/likes`, like, options).then((resl)=>console.log(resl)).catch((err)=>console.log(err));
            }
            for (const like1 of likesDB)redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_0__/* .addToLike */ .PZ)(like1));
        } else {
            for (const like2 of likesStore){
                if (!like2.id_usuario) like2.id_usuario = idUser;
                axios__WEBPACK_IMPORTED_MODULE_3___default().post(`${api}/likes`, like2, options).then((resl)=>console.log(resl)).catch((err)=>console.log(err));
            }
        }
    }).catch((err)=>console.log(err));
};
const getDataDelivey = (idUser, token)=>{
    const options = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    axios__WEBPACK_IMPORTED_MODULE_3___default().get(`${api}/defaultDelivery/${idUser}`, options).then((response)=>{
        const data = response.data.data[0];
        redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_0__/* .updateDeliveryData */ .Z3)(data));
    }).catch((err)=>console.log(err));
};
const getInvoiceDetailData = (idUser, token)=>{
    const options = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    axios__WEBPACK_IMPORTED_MODULE_3___default().get(`${api}/defaultInvoiceData/${idUser}`, options).then((response)=>{
        const data = response.data.data[0];
        redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_0__/* .updateInvoiceDetailData */ .vy)(data));
    }).catch((err)=>console.log(err));
};


/***/ }),

/***/ 5599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const Politics = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
            children: [
                "Al registrate o iniciar sesi\xf3n acepta los",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: "/terminos",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        children: " Terminos y Condiciones "
                    })
                }),
                "de nuestro portal web"
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Politics);


/***/ })

};
;