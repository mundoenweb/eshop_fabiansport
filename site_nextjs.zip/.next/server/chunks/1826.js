"use strict";
exports.id = 1826;
exports.ids = [1826];
exports.modules = {

/***/ 1826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Df": () => (/* binding */ removeFilterPubli),
/* harmony export */   "U3": () => (/* binding */ destacados),
/* harmony export */   "UE": () => (/* binding */ queryProductsBoard),
/* harmony export */   "Y1": () => (/* binding */ consultSales),
/* harmony export */   "hN": () => (/* binding */ searchCodeName),
/* harmony export */   "m_": () => (/* binding */ searchBoard),
/* harmony export */   "vY": () => (/* binding */ consultShopping)
/* harmony export */ });
/* harmony import */ var _Ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3070);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _useScripts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1514);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3619);





const api = "https://fabiansport.com/fs/api";
const apiNode = "https://apinode.fabiansport.com";
let response = null;
// realiza una consulta según los parametros del filtro personalizado
const queryProductsBoard = async (slugFilter, pages, setPages, setState)=>{
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
    if (!slugFilter.params.length && !slugFilter.descuento && !slugFilter.stock) {
        let response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/productosAdmin?page=${pages.pageCurrent}`);
        // response = await ajax(`${api}/api/productos?page=${pages.pageCurrent}`)
        if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return;
        setState(response.data.productos);
        setPages({
            pages: response.data.totalPage,
            pageCurrent: response.data.pageActual
        });
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
        return;
    }
    const json = new FormData();
    json.append("json", JSON.stringify(slugFilter));
    let response1 = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/productosAdminFiltro`, "POST", json);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response1)) return;
    setState(response1.data.productos);
    setPages({
        pages: response1.data.totalPage,
        pageCurrent: response1.data.pageActual
    });
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
};
// actualiza el estado de los parametros de consulta
const searchBoard = (e, setSlugFilter, modal)=>{
    e.preventDefault();
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
    let slug = {
        descuento: 0,
        pageActual: 1,
        stock: 0,
        relevancia: 0,
        params: []
    };
    for (const element of e.target){
        if (element.value) {
            switch(element.name){
                case "descuento":
                    if (element.checked) slug.descuento = 1;
                    break;
                case "stock":
                    if (element.checked) slug.stock = 1;
                    break;
                default:
                    const p = {};
                    p.campo = element.name;
                    p.valor = parseInt(element.value, 10);
                    slug.params.push(p);
                    break;
            }
        }
    }
    if (!slug.params.length && !slug.descuento && !slug.stock) {
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
        return alert("Debe seleccionar una opcion para poder buscar");
    }
    setSlugFilter(slug);
    (0,_useScripts__WEBPACK_IMPORTED_MODULE_4__/* .none */ .YP)(modal.current);
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
};
// Realiza una consulta por nombre o codigo
const searchCodeName = async (e, setState, setPages, refFormFilter)=>{
    e.preventDefault();
    let input = e.target.searchBoard, response;
    if (!input.value) {
        alert("debe escribir un codigo o nombre para filtrar");
        return;
    }
    // NProgress.start()
    const formData = new FormData();
    formData.append("json", JSON.stringify({
        value: input.value
    }));
    response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/buscador`, "POST", formData);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return;
    if (response.data.mensaje) return alert(`${response.data.mensaje}`);
    setState(response.data.productos);
    setPages({
        pages: 1,
        pageCurrent: 1
    });
    input.value = "";
    refFormFilter.reset();
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
};
// consulta las compras
const consultShopping = async (idUser, token, setShopping)=>{
    const options = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
    axios__WEBPACK_IMPORTED_MODULE_1___default()(`${apiNode}/invoices/user/${idUser}`, options).then((res)=>{
        let invoices = res.data.data;
        if (invoices.length) {
            for (const invoice of invoices){
                axios__WEBPACK_IMPORTED_MODULE_1___default()(`${apiNode}/shoppingCart/${invoice.codigo}`, options).then((items)=>{
                    invoice.products = items.data.data;
                });
            }
        }
        setTimeout(()=>{
            setShopping(res.data.data);
        }, 1000);
    }).catch((err)=>console.log(err)).then(()=>nprogress__WEBPACK_IMPORTED_MODULE_2___default().done());
};
// consulta las ventas
const consultSales = async (page, setSales, setPages)=>{
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
    const resp = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/facturasAdmin?page=${page}`);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(resp)) return nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
    setSales(resp.data.facturas);
    setPages({
        pages: resp.data.totalPage,
        pageCurrent: resp.data.pageActual
    });
    scroll(0, 0);
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
};
const removeFilterPubli = (setSlugFilter, refFormFilter)=>{
    refFormFilter.reset();
    setSlugFilter({
        descuento: 0,
        pageActual: 1,
        stock: 0,
        relevancia: 0,
        params: []
    });
};
// realiza una conulta de los productos más destacados
const destacados = async (setProductosDestacados)=>{
    const slugFilter = {
        descuento: 0,
        pageActual: 1,
        stock: 0,
        relevancia: 1,
        params: []
    };
    let data = new FormData();
    data.append("json", JSON.stringify(slugFilter));
    response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/productosFiltro`, "POST", data);
    setProductosDestacados(response.data.productos);
};


/***/ })

};
;