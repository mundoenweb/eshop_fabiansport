"use strict";
exports.id = 2196;
exports.ids = [2196];
exports.modules = {

/***/ 2196:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$R": () => (/* binding */ updateQuantity),
/* harmony export */   "Ee": () => (/* binding */ endSesion),
/* harmony export */   "Er": () => (/* binding */ updateProfileUser),
/* harmony export */   "HD": () => (/* binding */ updateFeatures),
/* harmony export */   "Ki": () => (/* binding */ resetObjectNewProduct),
/* harmony export */   "L1": () => (/* binding */ createPaletteColor),
/* harmony export */   "M$": () => (/* binding */ updateSex),
/* harmony export */   "Mn": () => (/* binding */ isPhone),
/* harmony export */   "PQ": () => (/* binding */ startSesion),
/* harmony export */   "PZ": () => (/* binding */ addToLike),
/* harmony export */   "Pg": () => (/* binding */ updateCost),
/* harmony export */   "Ri": () => (/* binding */ uploadImageProduct),
/* harmony export */   "Sw": () => (/* binding */ updateBrand),
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "YW": () => (/* binding */ updateDescription),
/* harmony export */   "Ys": () => (/* binding */ deleteImageProduct),
/* harmony export */   "Z3": () => (/* binding */ updateDeliveryData),
/* harmony export */   "_k": () => (/* binding */ updateCodeDad),
/* harmony export */   "h2": () => (/* binding */ removeFromCart),
/* harmony export */   "hd": () => (/* binding */ reloadStateFromLocalStorage),
/* harmony export */   "iB": () => (/* binding */ createProductChild),
/* harmony export */   "mG": () => (/* binding */ updateDescount),
/* harmony export */   "mZ": () => (/* binding */ deleteSize),
/* harmony export */   "n4": () => (/* binding */ updateCode),
/* harmony export */   "nM": () => (/* binding */ updateProduct),
/* harmony export */   "pD": () => (/* binding */ updateLinea),
/* harmony export */   "s9": () => (/* binding */ resetCart),
/* harmony export */   "sO": () => (/* binding */ createSize),
/* harmony export */   "tX": () => (/* binding */ updateName),
/* harmony export */   "vy": () => (/* binding */ updateInvoiceDetailData),
/* harmony export */   "wr": () => (/* binding */ deletFromLike),
/* harmony export */   "x$": () => (/* binding */ deleteProductFromCart),
/* harmony export */   "xR": () => (/* binding */ updateSize),
/* harmony export */   "yr": () => (/* binding */ updateCategory),
/* harmony export */   "zX": () => (/* binding */ changeColor)
/* harmony export */ });
/* unused harmony exports addTasa, updateAvatar, cartChangeQuantity, userDataInvoice, addDataPay */
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3077);

const API_URL = process.env.REACT_APP_API_URL;
// creacion y actualizacion de productos
const createPaletteColor = (colors)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_PALETTE_COLOR */ .cQ,
        colors
    });
const resetObjectNewProduct = (reset)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .RESET_OBJECT_NEW_PRODUCT */ .JF,
        reset
    });
const createProductChild = (product)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_PRODUCT_CHILD */ .mA,
        product
    });
const updateProduct = (articulo)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_PRODUCT */ .Q7,
        articulo
    });
const updateCode = (codigo)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_CODE */ .ZA,
        codigo
    });
const updateCodeDad = (codigo)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_CODE_DAD */ .sD,
        codigo
    });
const updateName = (name)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_NAME */ .MI,
        name
    });
const updateCost = (cost)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_COST */ .Cu,
        cost
    });
const updateDescount = (descount)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_DESCOUNT */ .wo,
        descount
    });
const updateSex = (sex)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_SEX */ .cs,
        sex
    });
const updateLinea = (linea)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_LINEA */ .VB,
        linea
    });
const updateCategory = (category)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_CATEGORY */ ._o,
        category
    });
const updateBrand = (brand)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_BRAND */ .b5,
        brand
    });
const updateFeatures = (features)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_FEATURES */ .Fh,
        features
    });
const updateDescription = (description)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_DESCRIPTION */ .ag,
        description
    });
const changeColor = (color)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_COLOR */ .wO,
        color
    });
const updateSize = (sizes)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_SIZE */ .ht,
        sizes
    });
const updateQuantity = (quantity)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_QUIANTITY */ .iI,
        quantity
    });
const createSize = (newSize)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .CREATE_SIZE */ .OP,
        newSize
    });
const deleteSize = (indexSeze)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .DELETE_SIZE */ .Sj,
        indexSeze
    });
const uploadImageProduct = (images)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPLOAD_IMAGE_PRODUCT */ .Lj,
        images
    });
const deleteImageProduct = (indexImage)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .DELETE_IMAGE_PRODUCT */ .Xg,
        indexImage
    });
// END
const reloadStateFromLocalStorage = (stateInitial)=>{
    return {
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .INITIAL_STATE */ .Y6,
        stateInitial
    };
};
const addTasa = (tasa)=>({
        type: ADD_TASA,
        tasa
    });
const isPhone = (value)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .IS_PHONE */ .vy,
        value
    });
const startSesion = (dataUser)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .START_SESION_EMAIL */ .EZ,
        dataUser
    });
const updateAvatar = (avatar)=>({
        type: ADD_AVATAR,
        avatar
    });
const endSesion = (close)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .CLOSE_SESION */ .PB,
        close
    });
const updateProfileUser = (dataUser)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_PROFILE_USER */ .Qb,
        dataUser: dataUser
    });
const updateDeliveryData = (data)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_DELIVERY_DATA */ .nb,
        data
    });
const updateInvoiceDetailData = (data)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .UPDATE_INVOICE_DETAIL_DATA */ .zu,
        data
    });
const addToCart = (data)=>{
    return {
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .GET_PRODUCT */ .N4,
        product: data
    };
};
const removeFromCart = (data)=>{
    return {
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .REMOVE_PRODUCT_FROM_CART */ ._Q,
        product: data
    };
};
const resetCart = (cart)=>{
    return {
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .RESET_CARRITO */ ._0,
        cart
    };
};
const deleteProductFromCart = (idDelete)=>{
    return {
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .DELET_PRODUCT_FROM_CART */ .vo,
        idDelete
    };
};
const cartChangeQuantity = (params)=>{
    return {
        type: CHANGE_QUANTIITY_CART_RPDUCT,
        params
    };
};
const addToLike = (product)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .GET_LIKE_PRODUCT */ .jj,
        product
    });
const deletFromLike = (product)=>({
        type: _actions__WEBPACK_IMPORTED_MODULE_0__/* .REMOVE_LIKE_PRODUCT */ .Tz,
        product
    });
const userDataInvoice = (data)=>({
        type: CREATE_DATA_USER_INVOICE,
        data
    });
const addDataPay = (pay)=>({
        type: ADD_DATA_PAY,
        pay
    }) // export const getAllSpecialities = () => dispatch => {
     //   Axios.get(`${API_URL}/especialidades`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_ALL_SPECIALITIES,
     //         specialities: resp.data
     //       })
     //     }
     //   )
     // }
     // export const getAllCourses = () => dispatch => {
     //   Axios.get(`${API_URL}/cursos`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_ALL_COURSES,
     //         courses: resp.data
     //       })
     //     }
     //   )
     // }
     // export const getAllTeachers = () => dispatch => {
     //   Axios.get(`${API_URL}/profesores`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_ALL_TEACHERS,
     //         teachers: resp.data
     //       })
     //     }
     //   )
     // }
     // export const getPost = id => dispatch => {
     //   Axios.get(`${API_URL}/posts/${id}`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_POST,
     //         post: resp.data
     //       })
     //     }
     //   )
     // }
     // export const getSpeciality = id => dispatch => {
     //   Axios.get(`${API_URL}/especialidad/${id}`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_SPECIALITY,
     //         speciality: resp.data
     //       })
     //     }
     //   )
     // }
     // export const getCourse = id => dispatch => {
     //   Axios.get(`${API_URL}/curso/${id}`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_COURSE,
     //         course: resp.data
     //       })
     //     }
     //   )
     // }
     // export const getFragment = id => dispatch => {
     //   Axios.get(`${API_URL}/clase/${id}`)
     //   .then(resp => {
     //       return dispatch({
     //         type: GET_FRAGMENT,
     //         fragment: resp.data
     //       })
     //     }
     //   )
     // }
;


/***/ })

};
;