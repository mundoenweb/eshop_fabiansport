"use strict";
exports.id = 1755;
exports.ids = [1755];
exports.modules = {

/***/ 3138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const InputCheckbox = ({ id ="" , labelText , name , value , referencia , css , fun , required  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
        className: `mw-flex label-checkbox ${css && css}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                id: id,
                type: "checkbox",
                name: name,
                ref: referencia && referencia,
                onChange: (e)=>fun && fun(e),
                className: "checkbox",
                value: value && value,
                required: required === false ? required : true
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: labelText || "favor pase un labelText como props"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputCheckbox);


/***/ }),

/***/ 7461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ useUpdateProfileUser),
/* harmony export */   "t": () => (/* binding */ useAddressOnInvoice)
/* harmony export */ });
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3619);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useValidetForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2001);
/* harmony import */ var _utils_handleBodyScroll__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8254);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2196);






const api = "https://apinode.fabiansport.com";
// actualiza los datos del usuario en la base de datos y en el estado global
// profileUser es la data actual del estado global
const useUpdateProfileUser = async (e, router, profileUser, token, dataDeliver, dataInvoice, formulary)=>{
    e.preventDefault();
    const form = formulary || e.target;
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_4__/* .validateForm */ .G)(form)) return nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
    const idUser = profileUser.id;
    const options = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    const profile = {
        email: profileUser.email,
        name: form.nameDelivery.value,
        is_adult: form.adult.checked
    };
    const dataDelivery = {
        id_usuario: profileUser.id,
        nombre: form.nameDelivery.value,
        departamento: form.departamentDelivery.value,
        provincia: form.provinceDelivery.value,
        distrito: form.districtDelivery.value,
        direccion: form.addressDelivery.value,
        referencia: form.refDelivery.value,
        telefono: form.phoneDelivery.value
    };
    const invoiceDetailData = {
        id_usuario: profileUser.id,
        correo: profileUser.email,
        razon_social: form.nameCompany.value,
        departamento: form.departamentBilling.value,
        provincia: form.provinceBilling.value,
        distrito: form.districtBilling.value,
        direccion: form.addressBilling.value,
        telefono: form.phoneBilling.value,
        tipo_documento: form.typeDocument.value,
        tipo_contribuyente: form.typeContribuyente.value,
        identificacion: form.dni.value
    };
    await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`${api}/users/${idUser}`, profile, options).then((res)=>{
        const data = res.data.data[0];
        _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateProfileUser */ .Er)(data));
    }).catch((err)=>console.log(err));
    // evalua si crea o actualizar
    // true actualiza 
    if (dataDeliver.id && dataInvoice.id) {
        console.log("actualizando datos");
        delete dataDelivery.id_usuario;
        delete invoiceDetailData.id_usuario;
        await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`${api}/defaultDelivery/${dataDeliver.id}`, dataDelivery, options).then((res)=>{
            const data = res.data.data[0];
            console.log(data);
            _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateDeliveryData */ .Z3)(data));
        }).catch((err)=>console.log(err));
        await axios__WEBPACK_IMPORTED_MODULE_1___default().put(`${api}/defaultInvoiceData/${dataInvoice.id}`, invoiceDetailData, options).then((res)=>{
            const data = res.data.data[0];
            console.log(data);
            _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateInvoiceDetailData */ .vy)(data));
        }).catch((err)=>console.log(err));
    } else {
        console.log("creando datos");
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${api}/defaultDelivery`, dataDelivery, options).then((res)=>{
            const data = res.data.data[0];
            _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateDeliveryData */ .Z3)(data));
        }).catch((err)=>console.log(err));
        await axios__WEBPACK_IMPORTED_MODULE_1___default().post(`${api}/defaultInvoiceData`, invoiceDetailData, options).then((res)=>{
            const data = res.data.data[0];
            _redux_store__WEBPACK_IMPORTED_MODULE_0__/* ["default"].dispatch */ .Z.dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateInvoiceDetailData */ .vy)(data));
        }).catch((err)=>console.log(err));
    }
    (0,_utils_handleBodyScroll__WEBPACK_IMPORTED_MODULE_5__/* .handleBodyScroll */ .C)();
    nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
// alert('datos actualizados correctamentea')
// store.dispatch(updateProfileUser(profile))
};
// reutiliza o no, la dirección de entrega como dirección de facturación.
// Ademas de ocular o mostrar los campos conrespondientes
const useAddressOnInvoice = (e)=>{
    if (e.target.checked) {
        departamentBilling.value = departamentDelivery.value;
        provinceBilling.value = provinceDelivery.value;
        districtBilling.value = districtDelivery.value;
        addressBilling.value = addressDelivery.value;
        phoneBilling.value = phoneDelivery.value;
        departamentBilling.readOnly = true;
        provinceBilling.readOnly = true;
        districtBilling.readOnly = true;
        addressBilling.readOnly = true;
        phoneBilling.readOnly = true;
    } else {
        departamentBilling.value = "";
        provinceBilling.value = "";
        districtBilling.value = "";
        addressBilling.value = "";
        phoneBilling.value = "";
        departamentBilling.readOnly = false;
        provinceBilling.readOnly = false;
        districtBilling.readOnly = false;
        addressBilling.readOnly = false;
        phoneBilling.readOnly = false;
    }
};


/***/ }),

/***/ 1755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _atoms_InputText__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2894);
/* harmony import */ var _atoms_InputNumber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9951);
/* harmony import */ var _atoms_InputSelect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7767);
/* harmony import */ var _atoms_InputCheckbox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3138);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hook_useUpdateProfileUser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7461);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);








const FormDateUser = ({ form , user , deliveryData , invoiceDetailData  })=>{
    const formReset = (formulary)=>formulary.reset();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (user.repeaInBilling) checkRepeatDir.checked = true;
        if (user.adult) adult.checked = true;
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mw-flex-row header-carrito",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "t2",
                        children: "DATOS DE ENTREGA"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        onClick: ()=>formReset(form.current),
                        children: "Nuevos datos"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "form-profile",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Nombre completo:",
                        name: "nameDelivery",
                        value: user.name
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Departamento",
                        name: "departamentDelivery",
                        value: deliveryData.departamento
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Provincia",
                        name: "provinceDelivery",
                        value: deliveryData.provincia
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Distrito",
                        name: "districtDelivery",
                        value: deliveryData.distrito
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Direcci\xf3n:",
                        name: "addressDelivery",
                        value: deliveryData.direccion
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Escriba una referencia:",
                        name: "refDelivery",
                        value: deliveryData.referencia
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputNumber__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        labelText: "Tel\xe9fono",
                        name: "phoneDelivery",
                        value: deliveryData.telefono
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputCheckbox__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        labelText: "Usar esta direcci\xf3n para la facturaci\xf3n",
                        id: "checkRepeatDir",
                        name: "repeatAddress",
                        css: "checkbox-repeat-address",
                        required: false,
                        fun: (e)=>(0,_hook_useUpdateProfileUser__WEBPACK_IMPORTED_MODULE_6__/* .useAddressOnInvoice */ .t)(e)
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mw-flex-row header-carrito",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: "t2",
                    children: "DATOS DE BOLETA O FACTURA"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "form-profile",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Raz\xf3n Social:",
                        name: "nameCompany",
                        value: invoiceDetailData.razon_social
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Escriba su correo:",
                        name: "emailBulling",
                        value: invoiceDetailData.correo || user.email
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        labelText: "Tipo de documento",
                        name: "typeDocument",
                        optionDefault: invoiceDetailData.typeDocument,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "boleta",
                                children: "boleta"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "factura",
                                children: "factura"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        labelText: "Tipo de contributente",
                        name: "typeContribuyente",
                        optionDefault: invoiceDetailData.tipoContribuyente,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "dni",
                                children: "DNI"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "cde",
                                children: "Carnet de Extranjeria"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "ruc",
                                children: "RUC - Solo en caso de factura"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "DNI / RUC / Carnet de Extranejeria:",
                        name: "dni",
                        value: invoiceDetailData.identificacion
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Escriba su departamento",
                        name: "departamentBilling",
                        value: deliveryData.departamento
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Escriba su provincia",
                        name: "provinceBilling",
                        value: deliveryData.provincia
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Escriba su distrito",
                        name: "districtBilling",
                        value: deliveryData.distrito
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputText__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        labelText: "Escriba su direcci\xf3n:",
                        name: "addressBilling",
                        value: deliveryData.direccion
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputNumber__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        labelText: "Tel\xe9fono",
                        name: "phoneBilling",
                        value: deliveryData.telefono
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_atoms_InputCheckbox__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                id: "adult",
                labelText: "Si soy mayor de 18 a\xf1os",
                name: "adult",
                required: true
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "button",
                children: "CONTINUAR"
            })
        ]
    });
};
const mapStateToProps = (state)=>({
        user: state.userReducer.dataUser,
        deliveryData: state.userReducer.deliveryData,
        invoiceDetailData: state.userReducer.invoiceDetailData
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_7__.connect)(mapStateToProps)(FormDateUser));


/***/ })

};
;