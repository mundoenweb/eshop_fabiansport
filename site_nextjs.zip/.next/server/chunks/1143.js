"use strict";
exports.id = 1143;
exports.ids = [1143];
exports.modules = {

/***/ 1143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ useRecoverEmail),
/* harmony export */   "v": () => (/* binding */ handleRecoverEmail_2)
/* harmony export */ });
/* harmony import */ var _Ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3070);
/* harmony import */ var _useValidetForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2001);


const useRecoverEmail = async (e)=>{
    e.preventDefault();
    const form = e.target;
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_1__/* .validateForm */ .G)(form)) return;
    const email = {
        email: form.email.value
    };
    const formData = new FormData();
    formData.append("json", JSON.stringify(email));
    const response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/recuperarClave`, "POST", formData);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return;
    form.reset();
    alert(`Favor revise su correo y siga las instrucciones`);
};
const handleRecoverEmail_2 = async (e, router)=>{
    e.preventDefault();
    const form = e.target;
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_1__/* .validateForm */ .G)(form)) return;
    if (form.password.value !== form.passwordTwo.value) {
        alert("las contrase\xf1as deben ser iguales");
        return;
    }
    const data = {
        clave: form.password.value,
        token: router.query.token,
        email: router.query.email
    };
    const formData = new FormData();
    formData.append("json", JSON.stringify(data));
    const response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/actualizarClave`, "POST", formData);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return;
    // return
    alert("clave actualizada correctamente");
    router.push("/login");
};


/***/ })

};
;