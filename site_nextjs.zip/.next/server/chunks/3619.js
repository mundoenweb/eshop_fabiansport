"use strict";
exports.id = 3619;
exports.ids = [3619];
exports.modules = {

/***/ 3619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ redux_store)
});

// EXTERNAL MODULE: external "redux"
var external_redux_ = __webpack_require__(6695);
// EXTERNAL MODULE: external "@redux-devtools/extension"
var extension_ = __webpack_require__(6807);
// EXTERNAL MODULE: ./redux/storeSaveAndLoad.js
var storeSaveAndLoad = __webpack_require__(1330);
// EXTERNAL MODULE: ./redux/stateInitial.js
var stateInitial = __webpack_require__(8406);
// EXTERNAL MODULE: ./redux/actions.js
var actions = __webpack_require__(3077);
;// CONCATENATED MODULE: ./redux/reducers.js


const appState = (state = stateInitial/* stateApp */.n1, action)=>{
    switch(action.type){
        case actions/* IS_PHONE */.vy:
            return {
                ...state,
                isPhone: action.value
            };
        case actions/* ADD_TASA */.Gx:
            return {
                ...state,
                tasa: action.tasa
            };
        case actions/* CREATE_PALETTE_COLOR */.cQ:
            return {
                ...state,
                colors: action.colors
            };
        default:
            return state;
    }
};
const userReducer = (state = stateInitial/* stateUser */.zU, action)=>{
    switch(action.type){
        case actions/* START_SESION_EMAIL */.EZ:
            return {
                ...state,
                logged: true,
                type: action.dataUser.type,
                dataUser: action.dataUser.user,
                token: action.dataUser.token
            };
        case actions/* UPDATE_PROFILE_USER */.Qb:
            return {
                ...state,
                dataUser: action.dataUser
            };
        case actions/* UPDATE_DELIVERY_DATA */.nb:
            return {
                ...state,
                deliveryData: action.data
            };
        case actions/* UPDATE_INVOICE_DETAIL_DATA */.zu:
            return {
                ...state,
                invoiceDetailData: action.data
            };
        case actions/* ADD_AVATAR */.T9:
            return {
                ...state,
                dataUser: {
                    ...state.dataUser,
                    avatar: action.avatar
                }
            };
        case actions/* CLOSE_SESION */.PB:
            return stateInitial/* stateUser */.zU;
        default:
            return state;
    }
};
const carritoReducer = (state = stateInitial/* stateCart */.ez, { type , cart , product , params , idDelete , data , pay  })=>{
    let costRemove = 0;
    switch(type){
        case actions/* GET_PRODUCT */.N4:
            return {
                ...state,
                products: state.products.concat(product),
                costSub: state.costSub += product.quantity * product.costo,
                costTotal: state.costSub + state.costSend
            };
        case actions/* REMOVE_PRODUCT_FROM_CART */._Q:
            for (const article of state.products){
                if (article.id === product.id) costRemove += article.quantity * article.costo;
            }
            return {
                ...state,
                products: state.products.filter((p)=>p.id !== product.id),
                costSub: state.costSub -= costRemove,
                costTotal: state.costSub + state.costSend
            };
        case actions/* DELET_PRODUCT_FROM_CART */.vo:
            for (const article1 of state.products){
                if (article1.idDelete === idDelete.id) costRemove = article1.quantity * article1.costo;
            }
            return {
                ...state,
                products: state.products.filter((p)=>p.idDelete !== idDelete.id),
                costSub: state.costSub -= costRemove,
                costTotal: state.costSub + state.costSend
            };
        case actions/* CHANGE_QUANTIITY_CART_RPDUCT */.fJ:
            let cost = 0;
            for (const article2 of state.products){
                if (article2.idDelete === params.id) article2.quantity = parseInt(params.quantity, 10);
                cost += article2.quantity * article2.costo;
            }
            return {
                ...state,
                costSub: cost,
                costTotal: cost + state.costSend
            };
        case actions/* CREATE_DATA_USER_INVOICE */._D:
            return {
                ...state,
                user: data
            };
        case actions/* ADD_DATA_PAY */.lA:
            return {
                ...state,
                pay
            };
        case actions/* RESET_CARRITO */._0:
            return stateInitial/* stateCart */.ez;
        default:
            return state;
    }
};
const likeReducer = (state = stateInitial/* stateLike */.Ij, { type , product  })=>{
    switch(type){
        case actions/* GET_LIKE_PRODUCT */.jj:
            if (state.products.find((p)=>p.codigo === product.codigo)) return state;
            return {
                ...state,
                products: state.products.concat(product)
            };
        case actions/* REMOVE_LIKE_PRODUCT */.Tz:
            return {
                ...state,
                products: state.products.filter((p)=>p.codigo != product.codigo)
            };
        default:
            return state;
    }
};
const newProduct = (state = stateInitial/* stateProductNew */.sQ, { type , product , codigo , color , sizes , quantity , newSize , indexSeze , images , indexImage , reset , name , cost , sex , category , linea , brand , descount , features , description , articulo  })=>{
    switch(type){
        case actions/* RESET_OBJECT_NEW_PRODUCT */.JF:
            return reset;
        case actions/* UPDATE_PRODUCT */.Q7:
            return {
                id: articulo.id,
                codigo: articulo.codigo,
                name: articulo.name,
                descuento: articulo.descuento,
                costo: articulo.costo,
                descripcion: articulo.descripcion,
                caracteristicas: articulo.caracteristicas,
                es_padre: articulo.es_padre,
                mi_padre: articulo.mi_padre,
                id_color: articulo.id_color,
                name_color: articulo.name_color,
                sizes: articulo.sizes,
                img: articulo.image,
                filtro: articulo.filtro
            };
        case actions/* CREATE_PRODUCT_CHILD */.mA:
            return {
                ...state,
                idDad: product.id,
                name: product.name,
                descuento: product.descuento,
                costo: product.costo,
                descripcion: product.descripcion,
                caracteristicas: product.caracteristicas,
                es_padre: false,
                mi_padre: product.mi_padre,
                imgDad: product.image[0],
                filtro: product.filtro
            };
        case actions/* UPDATE_CODE */.ZA:
            return {
                ...state,
                codigo
            };
        case actions/* UPDATE_CODE_DAD */.sD:
            return {
                ...state,
                mi_padre: codigo
            };
        case actions/* UPDATE_NAME */.MI:
            return {
                ...state,
                name
            };
        case actions/* UPDATE_COST */.Cu:
            return {
                ...state,
                costo: parseInt(cost)
            };
        case actions/* UPDATE_DESCOUNT */.wo:
            return {
                ...state,
                descuento: parseInt(descount)
            };
        case actions/* UPDATE_SEX */.cs:
            return {
                ...state,
                filtro: {
                    ...state.filtro,
                    sex: {
                        id: sex.id,
                        name: sex.name
                    }
                }
            };
        case actions/* UPDATE_LINEA */.VB:
            return {
                ...state,
                filtro: {
                    ...state.filtro,
                    linea: {
                        id: linea.id,
                        name: linea.name
                    }
                }
            };
        case actions/* UPDATE_CATEGORY */._o:
            return {
                ...state,
                filtro: {
                    ...state.filtro,
                    categoria: {
                        id: category.id,
                        name: category.name
                    }
                }
            };
        case actions/* UPDATE_BRAND */.b5:
            return {
                ...state,
                filtro: {
                    ...state.filtro,
                    marca: {
                        id: brand.id,
                        name: brand.name
                    }
                }
            };
        case actions/* UPDATE_FEATURES */.Fh:
            return {
                ...state,
                caracteristicas: features
            };
        case actions/* UPDATE_DESCRIPTION */.ag:
            return {
                ...state,
                descripcion: description
            };
        case actions/* UPDATE_COLOR */.wO:
            return {
                ...state,
                id_color: color.id_color,
                name_color: color.name_color,
                hexadecimal: color.hexadecimal
            };
        case actions/* UPDATE_SIZE */.ht:
            return {
                ...state,
                sizes: state.sizes.map((size, i)=>{
                    if (i === sizes.indexSeze) {
                        return {
                            ...size,
                            name: sizes.name
                        };
                    }
                    return size;
                })
            };
        case actions/* UPDATE_QUIANTITY */.iI:
            return {
                ...state,
                sizes: state.sizes.map((size, i)=>{
                    if (i === quantity.indexSeze) {
                        return {
                            ...size,
                            quantity: quantity.quantity
                        };
                    }
                    return size;
                })
            };
        case actions/* CREATE_SIZE */.OP:
            return {
                ...state,
                sizes: state.sizes.concat(newSize)
            };
        case actions/* DELETE_SIZE */.Sj:
            return {
                ...state,
                sizes: state.sizes.filter((s, index)=>index !== indexSeze)
            };
        case actions/* UPLOAD_IMAGE_PRODUCT */.Lj:
            return {
                ...state,
                img: state.img.concat(images)
            };
        case actions/* DELETE_IMAGE_PRODUCT */.Xg:
            return {
                ...state,
                img: state.img.filter((file, i)=>i !== indexImage)
            };
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./redux/store.js



// import thunk from "redux-thunk"

const appReducer = (0,external_redux_.combineReducers)({
    carritoReducer: carritoReducer,
    userReducer: userReducer,
    likeReducer: likeReducer,
    newProduct: newProduct,
    appState: appState
});
const rootReducer = (state, action)=>{
    if (action.type === "INITIAL_STATE") return action.stateInitial || state;
    return appReducer(state, action);
};
const store = (0,external_redux_.createStore)(rootReducer, (0,extension_.composeWithDevTools)());
// composeWithDevTools(applyMiddleware(thunk))
store.subscribe(function() {
    (0,storeSaveAndLoad/* saveState */.z)(store.getState());
});
/* harmony default export */ const redux_store = (store);


/***/ }),

/***/ 1330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ loadState),
/* harmony export */   "z": () => (/* binding */ saveState)
/* harmony export */ });
const saveState = (state)=>{
    try {
        let serializedData = JSON.stringify(state);
        localStorage.setItem("state", serializedData);
    } catch (error) {
        console.log("error al guardar el estado en localStorage");
        console.log(error);
    }
};
const loadState = ()=>{
    const serializedData = localStorage.getItem("state");
    if (serializedData === null) return undefined;
    return JSON.parse(serializedData);
};


/***/ })

};
;