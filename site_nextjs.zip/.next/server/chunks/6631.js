"use strict";
exports.id = 6631;
exports.ids = [6631];
exports.modules = {

/***/ 7089:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ButtonFormBasic = ({ text  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: "button btn-form-new-producto",
        children: [
            " ",
            text,
            " "
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonFormBasic);


/***/ }),

/***/ 1244:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Js": () => (/* binding */ updateProducts),
/* harmony export */   "Ry": () => (/* binding */ codeDadUpdate),
/* harmony export */   "WL": () => (/* binding */ handleNewProduct),
/* harmony export */   "Xs": () => (/* binding */ codeUpdate),
/* harmony export */   "ed": () => (/* binding */ nameUpdate),
/* harmony export */   "fI": () => (/* binding */ featuresUpdate),
/* harmony export */   "iL": () => (/* binding */ costUpdate),
/* harmony export */   "tV": () => (/* binding */ descountUpdate),
/* harmony export */   "yO": () => (/* binding */ descriptionUpdate)
/* harmony export */ });
/* harmony import */ var _Ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3070);
/* harmony import */ var _useValidetForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2001);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3619);
/* harmony import */ var redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2196);
/* harmony import */ var redux_stateInitial__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8406);






const api = "https://fabiansport.com/fs/api";
let response = null;
const codeUpdate = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateCode */ .n4)(evt.target.value));
const nameUpdate = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateName */ .tX)(evt.target.value));
const costUpdate = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateCost */ .Pg)(evt.target.value));
const descountUpdate = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateDescount */ .mG)(evt.target.value));
const featuresUpdate = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateFeatures */ .HD)(evt.target.value));
const descriptionUpdate = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateDescription */ .YW)(evt.target.value));
const codeDadUpdate = (evt)=>{
    redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateCode */ .n4)(evt.target.value));
    redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateCodeDad */ ._k)(evt.target.value));
};
const handleNewProduct = async (evt, articulo, router)=>{
    evt.preventDefault();
    const formulary = evt.target;
    const form = new FormData();
    const btnSubmit = formulary[formulary.length - 1];
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().start();
    btnSubmit.disabled = true;
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_5__/* .validateForm */ .G)(formulary)) {
        nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
        btnSubmit.disabled = false;
        return;
    }
    if (!articulo.img.length) {
        nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
        btnSubmit.disabled = false;
        alert("El producto debe tener como minimo una imagen");
        return;
    }
    for (const image of articulo.img){
        if (typeof image === "string") continue;
        form.append(`0[]`, image.file);
    }
    // descomentar las siguientes lines cuando finalicen las pruebas
    delete articulo.img;
    form.append("json", JSON.stringify(articulo));
    response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/crearProducto`, "POST", form);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
    alert("Registro exitoso");
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
    router.push("/app/admin/productos");
    redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .resetObjectNewProduct */ .Ki)(redux_stateInitial__WEBPACK_IMPORTED_MODULE_4__/* .stateProductNew */ .sQ));
};
const updateProducts = async (evt, articulo, router)=>{
    evt.preventDefault();
    const formulary = evt.target;
    const form = new FormData();
    const btnSubmit = formulary[formulary.length - 1];
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().start();
    btnSubmit.disabled = true;
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_5__/* .validateForm */ .G)(formulary)) {
        nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
        btnSubmit.disabled = false;
        return;
    }
    if (!articulo.img.length) {
        nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
        btnSubmit.disabled = false;
        alert("El producto debe tener como minimo una imagen");
        return;
    }
    for (const image of articulo.img){
        if (typeof image === "string") continue;
        form.append(`0[]`, image.file);
    }
    // descomentar las siguientes lines cuando finalicen las pruebas
    // delete articulo.img
    form.append("json", JSON.stringify(articulo));
    response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/actualizarProducto`, "POST", form);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
    alert("Actualizaci\xf3n exitosa");
    redux_store__WEBPACK_IMPORTED_MODULE_2__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .resetObjectNewProduct */ .Ki)(redux_stateInitial__WEBPACK_IMPORTED_MODULE_4__/* .stateProductNew */ .sQ));
    router.push("/app/admin/productos");
};


/***/ }),

/***/ 1504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7767);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3619);
/* harmony import */ var component_hook_Ajax__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3070);
/* harmony import */ var redux_actionCreators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2196);







const divSelectColor = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.createRef)();
const NewColorProduct = ({ paletteColor , articulo  })=>{
    const upluadColors = async ()=>{
        const colors = await (0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_5__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/colores`);
        redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_6__/* .createPaletteColor */ .L1)(colors.data.colores));
    };
    const colorUpdate = (evt)=>{
        let indexOption = evt.target.selectedIndex;
        let option = evt.target.options;
        redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_6__/* .changeColor */ .zX)({
            id_color: parseInt(evt.target.value, 10),
            name_color: option[indexOption].innerText,
            hexadecimal: option[indexOption].title
        }));
    };
    const createColor = async ()=>{
        let color, hexadecimal;
        do {
            color = prompt("Favor ingrese el nuevo color");
            if (color) color = color.toUpperCase();
        }while (color === "");
        if (!color) return;
        do {
            hexadecimal = prompt(`Ingrese el hexadecimal del color ${color}`);
            if (hexadecimal) hexadecimal = hexadecimal.toUpperCase();
        }while (hexadecimal === "");
        if (!hexadecimal) return;
        const select = divSelectColor.current.children[0].children[0];
        const formData = new FormData();
        formData.append("json", JSON.stringify({
            nombre: color,
            hexadecimal
        }));
        const response = await (0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_5__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/crearColor`, "POST", formData);
        // const response = await ajax(`${process.env.API}/crearColor`, 'POST', bodyMsg)
        if (!(0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_5__/* .valideteResponse */ .s)(response)) return;
        const colors = await (0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_5__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/colores`);
        redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_6__/* .createPaletteColor */ .L1)(colors.data.colores));
        alert("color agregado exitosamente");
        select.selectedIndex = select.options.length - 1;
        const currentColor = colors.data.colores[colors.data.colores.length - 1];
        redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_6__/* .changeColor */ .zX)({
            id_color: parseInt(currentColor.id),
            name_color: currentColor.nombre
        }));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        upluadColors();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "box-color-new-product",
            ref: divSelectColor,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        background: `#${articulo.hexadecimal}`
                    },
                    className: "circle-color"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    onchange: colorUpdate,
                    title: "color",
                    labelText: "Selecciona un color",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("option", {
                            value: articulo.id_color || "",
                            children: [
                                " ",
                                articulo.name_color || "",
                                " "
                            ]
                        }),
                        paletteColor.map((color)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                title: color.hexadecimal,
                                value: color.id,
                                children: color.nombre
                            }, color.id))
                    ]
                })
            ]
        })
    });
};
const mapStateToProps = (state)=>({
        paletteColor: state.appState.colors,
        articulo: state.newProduct
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_3__.connect)(mapStateToProps)(NewColorProduct));


/***/ }),

/***/ 3720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var component_hook_Ajax__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3070);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2196);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3619);






const UploadImage = ({ images , productoID  })=>{
    const renderImage = (file, arrImages, productoID)=>{
        return new Promise((resolve, reject)=>{
            const fileRender = new FileReader();
            fileRender.readAsDataURL(file);
            fileRender.addEventListener("load", ()=>{
                const image = {
                    file: file,
                    preview: fileRender.result
                };
                arrImages.push(image);
                resolve();
            });
        });
    };
    const addUploadImage = async (input)=>{
        const files = input.files;
        const imgsCurrent = images.length;
        let arrImages = [], imgMax = 6;
        if (files.length > imgMax - imgsCurrent) {
            input.type = "text";
            input.type = "file";
            return alert(`Solo puede seleccionar ${imgMax - imgsCurrent} imagenes`);
        }
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
        if (files[0]) await renderImage(files[0], arrImages);
        if (files[1]) await renderImage(files[1], arrImages);
        if (files[2]) await renderImage(files[2], arrImages);
        if (files[3]) await renderImage(files[3], arrImages);
        if (files[4]) await renderImage(files[4], arrImages);
        if (files[5]) await renderImage(files[5], arrImages);
        redux_store__WEBPACK_IMPORTED_MODULE_5__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__/* .uploadImageProduct */ .Ri)(arrImages));
        input.type = "text";
        input.type = "file";
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
    };
    const removeUploadImage = async (indexImage, img)=>{
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
        if (images[indexImage].file) {
            redux_store__WEBPACK_IMPORTED_MODULE_5__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__/* .deleteImageProduct */ .Ys)(indexImage));
            // img.filter((s, i) => i !== indexImage)
            return nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
        }
        if (!confirm("\xbfseguro que desea borrar esta imagen permanentemente?")) return;
        let arrText = img.split("/");
        img = arrText[arrText.length - 1];
        const formDate = new FormData();
        formDate.append("json", JSON.stringify({
            imagen: {
                nombre: img,
                id: productoID,
                directorio: "productos"
            }
        }));
        const response = await (0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_1__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/eliminarImagen`, "POST", formDate);
        if (!(0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_1__/* .valideteResponse */ .s)(response)) return;
        redux_store__WEBPACK_IMPORTED_MODULE_5__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__/* .deleteImageProduct */ .Ys)(indexImage));
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "box-main-uploader",
        children: [
            images.length === 6 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                children: "Imagenes Completas"
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: "button-upload-products ",
                htmlFor: "btn_upload_image",
                children: [
                    "Subir Imagenes del producto",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        id: "btn_upload_image",
                        onChange: (e)=>addUploadImage(e.target),
                        accept: ".webp, .jpg, .png|image/*",
                        type: "file",
                        name: "btn_upload_image",
                        className: "upload ignore",
                        multiple: true
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "box-uploader-products",
                children: images.map((img, indexImage)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "box-input-image",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: "image-product-upload",
                                src: img.preview ? img.preview : img,
                                alt: "image"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "delet-input-upload",
                                onClick: ()=>removeUploadImage(indexImage, img),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `${"/"}images/delet.svg`,
                                    alt: "delete",
                                    className: "img-delete"
                                })
                            })
                        ]
                    }, indexImage))
            })
        ]
    });
};
const mapStateToProps = (state)=>({
        images: state.newProduct.img,
        productoID: state.newProduct.id
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_3__.connect)(mapStateToProps)(UploadImage));


/***/ }),

/***/ 3954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ organisms_MultipleSizes)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./component/atoms/InputNumber.jsx
var InputNumber = __webpack_require__(9951);
// EXTERNAL MODULE: ./component/atoms/InputSelect.jsx
var InputSelect = __webpack_require__(7767);
// EXTERNAL MODULE: ./redux/store.js + 1 modules
var store = __webpack_require__(3619);
// EXTERNAL MODULE: ./redux/actionCreators.js
var actionCreators = __webpack_require__(2196);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./component/hook/Ajax.js
var Ajax = __webpack_require__(3070);
;// CONCATENATED MODULE: ./component/molecules/SizeAndQuantity.jsx








const SizeAndQuantity = ({ articulo , sizesState , indexSeze , valueSize  })=>{
    const { 0: sizeCurrentForm , 1: setSizeCurrentForm  } = (0,external_react_.useState)([]);
    const loadSizes = ()=>{
        const sexo = articulo.filtro.sex.name;
        const linea = articulo.filtro.linea.name;
        switch(linea){
            case "calzado":
                if (sizesState.calzado[sexo]) {
                    setSizeCurrentForm(sizesState.calzado[sexo].map((size)=>size));
                } else if (sexo === "ni\xf1os" || sexo === "ni\xf1as") {
                    setSizeCurrentForm(sizesState.calzado.ninos.map((size)=>size));
                } else setSizeCurrentForm([]);
                break;
            case "ropa":
                if (sizesState.ropa[sexo]) setSizeCurrentForm(sizesState.ropa[sexo]);
                else if (sexo === "ni\xf1os" || sexo === "ni\xf1as") setSizeCurrentForm(sizesState.ropa.ninos);
                else setSizeCurrentForm([]);
                break;
            case "accesorios":
                setSizeCurrentForm([
                    sizesState.accesorios
                ]);
                break;
            default:
                setSizeCurrentForm([]);
                break;
        }
    };
    const sizeUpdate = (indexSeze, name)=>store/* default.dispatch */.Z.dispatch((0,actionCreators/* updateSize */.xR)({
            indexSeze,
            name
        }));
    const quantityUpdate = (indexSeze, quantity)=>store/* default.dispatch */.Z.dispatch((0,actionCreators/* updateQuantity */.$R)({
            indexSeze,
            quantity
        }));
    const createNewSize = ()=>{
        const newSize = {
            id: null,
            name: "",
            quantity: 0
        };
        const findChildren = articulo.sizes.length - 1;
        if (!articulo.sizes[findChildren].name || !articulo.sizes[findChildren].quantity) {
            alert("debe agregar una talla y cantidad, antes de crear una nueva talla");
            return;
        }
        store/* default.dispatch */.Z.dispatch((0,actionCreators/* createSize */.sO)(newSize));
    };
    const sizeDelete = async (id)=>{
        if (articulo.sizes.length === 1) return alert("Debe existir almenos una talla con su cantidad");
        function supr(indexSeze) {
            setSizeCurrentForm([]);
            store/* default.dispatch */.Z.dispatch((0,actionCreators/* deleteSize */.mZ)(indexSeze));
            setTimeout(()=>{
                loadSizes();
            }, 500);
        }
        if (id) {
            if (confirm("\xbfSeguro desea eliminar la talla?, se borrara definitivamente")) {
                const response = await (0,Ajax/* ajax */.h)(`${"https://fabiansport.com/fs/api"}/eliminarTalla/${id}`, "POST");
                if (!(0,Ajax/* valideteResponse */.s)(response)) return;
                supr(indexSeze);
            }
            return;
        }
        supr(indexSeze);
    };
    const onblur = (e)=>{
        const input = e.target.name, value = e.target.value;
        if (input === `size_${indexSeze}`) {
            sizeUpdate(indexSeze, value);
            return;
        }
        quantityUpdate(indexSeze, parseInt(value, 10));
    };
    (0,external_react_.useEffect)(()=>{
        loadSizes();
    }, [
        articulo.filtro
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "box-size-quantity",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(InputSelect/* default */.Z, {
                name: `size_${indexSeze}`,
                onchange: "",
                labelText: "Talla",
                onchange: onblur,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                        children: valueSize.name
                    }),
                    sizeCurrentForm.map((size, i)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                            value: size,
                            children: size
                        }, i))
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(InputNumber/* default */.Z, {
                onblur: onblur,
                value: valueSize.quantity || "0",
                labelText: "Cantidad",
                name: `quantity_${indexSeze}`
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "box-button-add-another",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "button button-add-another",
                        onClick: ()=>createNewSize(),
                        children: "+"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "button button-add-another button-remove-another",
                        onClick: ()=>sizeDelete(valueSize.id),
                        children: "-"
                    })
                ]
            })
        ]
    });
};
const mapStateToProps = (state)=>({
        sizesState: state.appState.sizes,
        articulo: state.newProduct
    });
/* harmony default export */ const molecules_SizeAndQuantity = ((0,external_react_redux_.connect)(mapStateToProps)(SizeAndQuantity));

;// CONCATENATED MODULE: ./component/organisms/MultipleSizes.jsx



const MultipleSizes = ({ articulo  })=>articulo.sizes.map((size, index)=>/*#__PURE__*/ jsx_runtime_.jsx(molecules_SizeAndQuantity, {
            indexSeze: index,
            valueSize: size
        }, index));
const MultipleSizes_mapStateToProps = (state)=>({
        articulo: state.newProduct
    });
/* harmony default export */ const organisms_MultipleSizes = ((0,external_react_redux_.connect)(MultipleSizes_mapStateToProps)(MultipleSizes));


/***/ })

};
;