"use strict";
exports.id = 3499;
exports.ids = [3499];
exports.modules = {

/***/ 7220:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Vu": () => (/* binding */ toShowModal),
/* harmony export */   "_H": () => (/* binding */ toNoneModal),
/* harmony export */   "gd": () => (/* binding */ closeModals)
/* harmony export */ });
/* harmony import */ var _useScripts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1514);

const toShowModal = (modal)=>{
    modal = modal.current;
    (0,_useScripts__WEBPACK_IMPORTED_MODULE_0__/* .toShow */ .tA)(modal);
};
const toNoneModal = (modal)=>{
    modal = modal.current;
    (0,_useScripts__WEBPACK_IMPORTED_MODULE_0__/* .none */ .YP)(modal);
    resetFormModal(modal.children[0].children[1].children);
};
/* Cerrar modales */ const closeModals = (e)=>{
    let boxModal = e.nativeEvent.path[3];
    let contentModal = e.nativeEvent.path[2].children[1].children;
    resetFormModal(contentModal);
    (0,_useScripts__WEBPACK_IMPORTED_MODULE_0__/* .none */ .YP)(boxModal);
};
const resetFormModal = (modal)=>{
    console.log(modal);
    for (const i of modal){
        if (i.localName === "form") i.reset();
        for (const e of i.children){
            if (e.localName === "form") e.reset();
        }
    }
};


/***/ }),

/***/ 2979:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ updateStatusVenta),
/* harmony export */   "m": () => (/* binding */ updateDescount)
/* harmony export */ });
/* harmony import */ var _Ajax__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3070);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _useModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7220);
/* harmony import */ var _useValidetForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2001);




const api = "https://fabiansport.com/fs/api";
let response = null;
// modifica el status de la venta
const updateStatusVenta = async (e, state, setState, modal)=>{
    e.preventDefault();
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_2__/* .validateForm */ .G)(e.target)) return;
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().start();
    const formData = new FormData();
    const id = parseInt(e.target.idVenta.value, 10), delivery = e.target.status.value, guia = e.target.guia.value, slug = {
        id,
        delivery,
        guia
    };
    formData.append("json", JSON.stringify(slug));
    response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/asignarInfoEntrega`, "POST", formData);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return;
    setState(state.map((p)=>{
        if (p.id === id) return {
            ...p,
            delivery,
            guia,
            status: true
        };
        return p;
    }));
    (0,_useModal__WEBPACK_IMPORTED_MODULE_3__/* .toNoneModal */ ._H)(modal);
    alert("estatus actualizado correctamente");
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
};
// actualiza el descuento del producto
const updateDescount = async (e, products, setProducts, modalDescount)=>{
    e.preventDefault();
    if (!(0,_useValidetForm__WEBPACK_IMPORTED_MODULE_2__/* .validateForm */ .G)(e.target)) return;
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().start();
    const id = parseInt(e.target.idProduct.value, 10);
    const descount = parseInt(e.target.descount.value, 10);
    const data = {
        producto: {
            id,
            descuento: descount
        }
    };
    const formData = new FormData();
    formData.append("json", JSON.stringify(data));
    response = await (0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .ajax */ .h)(`${api}/actualizarDescuento`, "POST", formData);
    if (!(0,_Ajax__WEBPACK_IMPORTED_MODULE_0__/* .valideteResponse */ .s)(response)) return (0,_useModal__WEBPACK_IMPORTED_MODULE_3__/* .toNoneModal */ ._H)(modalDescount);
    (0,_useModal__WEBPACK_IMPORTED_MODULE_3__/* .toNoneModal */ ._H)(modalDescount);
    alert("descuento aplicado exitosamente");
    setProducts(products.map((p)=>{
        if (p.id === id) {
            return {
                ...p,
                descuento: descount
            };
        }
        return p;
    }));
    nprogress__WEBPACK_IMPORTED_MODULE_1___default().done();
};


/***/ }),

/***/ 1239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_handleBodyScroll__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8254);


const BtnPaginationAdmin = ({ pages , setPages , slugFilter , setSlugFilter  })=>{
    const nextPag = ()=>{
        setPages({
            ...pages,
            pageCurrent: pages.pageCurrent + 1
        });
        setSlugFilter({
            ...slugFilter,
            pageActual: slugFilter.pageActual + 1
        });
        (0,_utils_handleBodyScroll__WEBPACK_IMPORTED_MODULE_1__/* .handleBodyScroll */ .C)();
    };
    const backPag = ()=>{
        setPages({
            ...pages,
            pageCurrent: pages.pageCurrent - 1
        });
        setSlugFilter({
            ...slugFilter,
            pageActual: slugFilter.pageActual - 1
        });
        (0,_utils_handleBodyScroll__WEBPACK_IMPORTED_MODULE_1__/* .handleBodyScroll */ .C)();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "pagination",
        children: [
            pages.pageCurrent === 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: "a-inactive",
                children: "Atras"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                onClick: ()=>backPag(),
                children: "Atras"
            }),
            "|",
            pages.pageCurrent < pages.pages ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                onClick: ()=>nextPag(),
                children: "Siguiente"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: "a-inactive",
                children: "Siguiente"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BtnPaginationAdmin);


/***/ }),

/***/ 4365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hook_useModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7220);


const Modal = ({ children , name , typeModal , referencia  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "boxBaseModal",
        ref: referencia,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `boxWindowModal boxShadow box-animate-top ${typeModal}`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "titleWindow",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: name
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "closeModal",
                            onClick: (e)=>(0,_hook_useModal__WEBPACK_IMPORTED_MODULE_1__/* .closeModals */ .gd)(e),
                            children: "\xd7"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "BoxContentWindow",
                    children: children
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Modal);


/***/ })

};
;