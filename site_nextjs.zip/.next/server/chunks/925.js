"use strict";
exports.id = 925;
exports.ids = [925];
exports.modules = {

/***/ 925:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _hook_Ajax__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3070);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2196);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);






const Like = ({ isLogged , token , id_usuario , css ="" , codigo , descuento , id , name , cost , image , listLike , addToLikeProduct , deletFromLikeProduct  })=>{
    const api = "https://apinode.fabiansport.com";
    const options = {
        headers: {
            Authorization: `Bearer ${token}`
        }
    };
    const addLike = async ()=>{
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
        let product = {
            id_producto: id,
            id_usuario,
            codigo,
            descuento,
            name,
            costo: cost,
            img: image
        };
        if (!isLogged) {
            addToLikeProduct(product);
            nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
            return;
        }
        axios__WEBPACK_IMPORTED_MODULE_5___default().post(`${api}/likes`, product, options).then((res)=>{
            const id = res.data.data.insertId;
            product.id = id;
            addToLikeProduct(product);
        }).catch((err)=>{
            alert("hubo un error de nuestro lado, favor intenta mas tarde");
            console.log(err);
        }).then(()=>nprogress__WEBPACK_IMPORTED_MODULE_2___default().done());
    };
    const removeLike = async ()=>{
        const product = {
            codigo
        };
        const like = listLike.find((p)=>p.codigo === codigo);
        const idLike = like.id;
        nprogress__WEBPACK_IMPORTED_MODULE_2___default().start();
        if (idLike) {
            axios__WEBPACK_IMPORTED_MODULE_5___default()["delete"](`${api}/likes/${idLike}`, options).then((res)=>{
                console.log(res);
                deletFromLikeProduct(product);
            }).catch((err)=>console.log(err)).then(()=>nprogress__WEBPACK_IMPORTED_MODULE_2___default().done());
        } else {
            deletFromLikeProduct(product);
            nprogress__WEBPACK_IMPORTED_MODULE_2___default().done();
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: listLike.find((p)=>p.id_producto === id) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            className: css,
            onClick: ()=>removeLike(),
            src: `/images/corazon_relleno.svg`,
            alt: "removeLike"
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            className: css,
            onClick: ()=>addLike(),
            src: `/images/corazon_vacio.svg`,
            alt: "addLike"
        })
    });
};
const mapStateToProps = (state)=>({
        listLike: state.likeReducer.products,
        isLogged: state.userReducer.logged,
        id_usuario: state.userReducer.dataUser.id,
        token: state.userReducer.token
    });
const mapDispatchToProps = (dispatch)=>({
        addToLikeProduct (product) {
            dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__/* .addToLike */ .PZ)(product));
        },
        deletFromLikeProduct (product) {
            dispatch((0,_redux_actionCreators__WEBPACK_IMPORTED_MODULE_4__/* .deletFromLike */ .wr)(product));
        }
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_3__.connect)(mapStateToProps, mapDispatchToProps)(Like));


/***/ })

};
;