"use strict";
exports.id = 259;
exports.ids = [259];
exports.modules = {

/***/ 1923:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const InputTextTarea = ({ labelText , name , title , cssLabel , value , required , onblur  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (value) document.getElementById(name).value = value || "";
    }, [
        value
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
        className: cssLabel,
        children: [
            labelText || "favor pase un labelText como props",
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                onBlur: (e)=>onblur && onblur(e),
                id: name,
                type: "text",
                name: name,
                title: title,
                className: required === false ? "" : "required"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "msgAlertForm"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputTextTarea);


/***/ }),

/***/ 8663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7767);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2196);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3619);





const SelectsFiltersNewProduct = ({ slugFilters , articulo  })=>{
    const changeSex = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateSex */ .M$)({
            id: parseInt(evt.target.value, 10),
            name: evt.target.options[evt.target.selectedIndex].innerText
        }));
    const changeLinea = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateLinea */ .pD)({
            id: parseInt(evt.target.value, 10),
            name: evt.target.options[evt.target.selectedIndex].innerText
        }));
    const changeCategory = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateCategory */ .yr)({
            id: parseInt(evt.target.value, 10),
            name: evt.target.options[evt.target.selectedIndex].innerText
        }));
    const changeBrand = (evt)=>redux_store__WEBPACK_IMPORTED_MODULE_4__/* ["default"].dispatch */ .Z.dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_3__/* .updateBrand */ .Sw)({
            id: parseInt(evt.target.value, 10),
            name: evt.target.options[evt.target.selectedIndex].innerText
        }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                onchange: changeSex,
                title: "sexo",
                labelText: "Selecciona el Sexo",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: articulo.filtro.sex.id || "",
                        children: articulo.filtro.sex.name || ""
                    }),
                    slugFilters.sexo.map((s)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: s.id,
                            children: s.name
                        }, s.id))
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                onchange: changeLinea,
                title: "linea",
                labelText: "Selecciona la Linea",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: articulo.filtro.linea.id || "",
                        children: articulo.filtro.linea.name || ""
                    }),
                    slugFilters.linea.map((s)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: s.id,
                            children: s.name
                        }, s.id))
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                onchange: changeCategory,
                title: "categor\xeda",
                labelText: "Selecciona la categor\xeda",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: articulo.filtro.categoria.id || "",
                        children: articulo.filtro.categoria.name || ""
                    }),
                    slugFilters.categorias.map((s)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: s.id,
                            children: s.name
                        }, s.id))
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(component_atoms_InputSelect__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                onchange: changeBrand,
                title: "marca",
                labelText: "Selecciona la marca",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: articulo.filtro.marca.id || "",
                        children: articulo.filtro.marca.name || ""
                    }),
                    slugFilters.marcas.map((s)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: s.id,
                            children: s.name
                        }, s.id))
                ]
            })
        ]
    });
};
const mapStateToProps = (state)=>({
        slugFilters: state.appState.filters,
        articulo: state.newProduct
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)(mapStateToProps)(SelectsFiltersNewProduct));


/***/ })

};
;