"use strict";
exports.id = 3070;
exports.ids = [3070];
exports.modules = {

/***/ 3070:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ ajax),
/* harmony export */   "s": () => (/* binding */ valideteResponse)
/* harmony export */ });
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_0__);

/** 
 * @function ajax Se encarga de realizar una peticion o enviar informacion al backend
   para que la procese y nos de una respuesta tipo JSON

 * Si se va a realizar una peticion basta con:
   @function ajax(url)

 * Si se va a enviar información debe pasar:
   @function ajax(url,method,body)      
   la body debe ser un Objeto, Array ó FormData()

 * Si desea agregar o eliminar cabeceras, se debe pasar como un callback
   @function ajax(url,metodo,body,callback)
   ejemplo: const agregarCabecera = cabecera => {cabecera.append('teken','12345')}
*/ const ajax = async (url, method = "GET", body = null, callback)=>{
    let cL = console.log, data, response, mode = "cors";
    const headers = new Headers();
    if (callback) callback(headers);
    if (body && Object.entries(body).length) {
        // cL('body:'); cL(body)
        body = JSON.stringify(body);
        headers.append("Content-Type", "application/json;charset=utf-8");
    }
    const myConfig = {
        method,
        mode,
        headers,
        body
    };
    try {
        response = await fetch(url, myConfig);
    } catch (err) {
        // cL(err)
        response = {
            status: "failed"
        };
    }
    try {
        data = await response.json();
        response.data = data;
    } catch (err1) {
        cL("no se puede convertir el objeto a json");
    }
    // cL('Response:'); cL(response)
    return response;
};
const valideteResponse = (response)=>{
    switch(response.status){
        case 200:
            return true;
        case 201:
            return true;
        case 401:
            alert("Acceso no autorizado");
            nprogress__WEBPACK_IMPORTED_MODULE_0___default().done();
            return false;
        case "failed":
            alert("Favor verifique su conexion a internet");
            nprogress__WEBPACK_IMPORTED_MODULE_0___default().done();
            return false;
        default:
            alert(`${response.data.mensaje}`);
            nprogress__WEBPACK_IMPORTED_MODULE_0___default().done();
            return false;
    }
};



/***/ })

};
;