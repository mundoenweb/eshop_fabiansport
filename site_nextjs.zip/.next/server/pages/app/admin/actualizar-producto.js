"use strict";
(() => {
var exports = {};
exports.id = 4129;
exports.ids = [4129];
exports.modules = {

/***/ 6156:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _component_atoms_InputNumber__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9951);
/* harmony import */ var _component_atoms_InputText__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2894);
/* harmony import */ var _component_atoms_InputTextTarea__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1923);
/* harmony import */ var _component_molecules_UploadImage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3720);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1244);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var component_molecules_BarOptions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6800);
/* harmony import */ var component_organisms_MultipleSizes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3954);
/* harmony import */ var component_molecules_NewColorProduct__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1504);
/* harmony import */ var component_molecules_SelectsFiltersNewProduct__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8663);
/* harmony import */ var component_atoms_Private__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6147);
/* harmony import */ var component_atoms_ButtonFormBasic__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7089);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var component_hook_Ajax__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3070);
/* harmony import */ var redux_store__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3619);
/* harmony import */ var redux_actionCreators__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2196);


















const NewProduct = ({ articulo , articuloSR , isLogged , typeUser , rdxUpdateProduct  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_14__.useEffect)(()=>{
        if (!articuloSR) {
            alert("el producto que desea actualizar no existe");
            router.push("productos");
        }
    }, [
        articuloSR,
        router
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_14__.useEffect)(()=>{
        if (isLogged) {
            rdxUpdateProduct(articuloSR);
        }
    }, [
        articuloSR,
        isLogged,
        rdxUpdateProduct
    ]);
    // if (!isLogged || typeUser != 1) return <Private />
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mw-grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(component_molecules_BarOptions__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        onSubmit: (e)=>(0,_component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .updateProducts */ .Js)(e, articulo, router),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "form-profile",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "t2 title-form",
                                        children: "Registro producto principal"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_atoms_InputText__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        onblur: (code)=>articulo.es_padre === 1 ? (0,_component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .codeDadUpdate */ .Ry)(code) : (0,_component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .codeUpdate */ .Xs)(code),
                                        labelText: "Codigo del producto",
                                        title: "codigo",
                                        name: "codigo",
                                        value: articulo.codigo,
                                        upperCase: true
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_atoms_InputText__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        onblur: _component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .nameUpdate */ .ed,
                                        title: "nombre",
                                        labelText: "Nombre",
                                        name: "name",
                                        value: articulo.name,
                                        upperCase: true
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_atoms_InputNumber__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        onblur: _component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .costUpdate */ .iL,
                                        validateType: "moneda",
                                        title: "costo",
                                        labelText: "Costo",
                                        name: "costo",
                                        value: articulo.costo
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_atoms_InputNumber__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        onblur: _component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .descountUpdate */ .tV,
                                        labelText: "Descuento",
                                        title: "descuento",
                                        name: "descuento",
                                        value: articulo.descuento || "0"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(component_molecules_SelectsFiltersNewProduct__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_atoms_InputText__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        onblur: _component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .featuresUpdate */ .fI,
                                        title: "caracteristicas",
                                        name: "caracteristicas",
                                        labelText: "Caracteristicas",
                                        required: false,
                                        value: articulo.caracteristicas
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_atoms_InputTextTarea__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        onblur: _component_hook_handleNewProduct__WEBPACK_IMPORTED_MODULE_6__/* .descriptionUpdate */ .yO,
                                        required: false,
                                        title: "descripci\xf3n",
                                        name: "descripcion",
                                        labelText: "Descripcion del Producto",
                                        cssLabel: "texttarea-description-product",
                                        value: articulo.descripcion
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(component_molecules_NewColorProduct__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(component_organisms_MultipleSizes__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_component_molecules_UploadImage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(component_atoms_ButtonFormBasic__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                text: "PUBLICAR"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mw-grid separador"
            })
        ]
    });
};
async function getServerSideProps({ query  }) {
    let articulo = null;
    if (query.id) {
        const res = await (0,component_hook_Ajax__WEBPACK_IMPORTED_MODULE_15__/* .ajax */ .h)(`${"https://fabiansport.com/fs/api"}/productoDetalle/${query.id}`);
        if (res.data.mensaje) articulo = null;
        else articulo = res.data;
    }
    return {
        props: {
            articuloSR: articulo
        }
    };
}
const mapStateToProps = (state)=>({
        isLogged: state.userReducer.logged,
        typeUser: state.userReducer.dataUser.role,
        articulo: state.newProduct
    });
const mapDispathToProps = (dispatch)=>({
        rdxUpdateProduct (product) {
            dispatch((0,redux_actionCreators__WEBPACK_IMPORTED_MODULE_17__/* .updateProduct */ .nM)(product));
        }
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_5__.connect)(mapStateToProps, mapDispathToProps)(NewProduct));


/***/ }),

/***/ 6807:
/***/ ((module) => {

module.exports = require("@redux-devtools/extension");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

module.exports = require("nprogress");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("redux");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3077,8406,3070,3619,6147,2196,2001,883,7767,9951,6800,6631,259], () => (__webpack_exec__(6156)));
module.exports = __webpack_exports__;

})();