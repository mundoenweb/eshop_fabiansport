"use strict";
(() => {
var exports = {};
exports.id = 2116;
exports.ids = [2116];
exports.modules = {

/***/ 9161:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ButtonBack)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


function ButtonBack() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const qtyComponent = ()=>{
        if (Object.entries(router.components).length === 2) router.push("/productos/todos");
        else router.back();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        onClick: ()=>qtyComponent(),
        children: "Atras"
    });
};


/***/ }),

/***/ 135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const PaymentTypeImage = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "aside-opciones-pago",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "t2",
                children: "OPCIONES DE PAGO"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: `${"/"}images/opciones-pago.png`,
                alt: "tipos de pago"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentTypeImage);


/***/ }),

/***/ 4243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./redux/actionCreators.js
var actionCreators = __webpack_require__(2196);
// EXTERNAL MODULE: ./redux/store.js + 1 modules
var store = __webpack_require__(3619);
;// CONCATENATED MODULE: ./component/hook/handleBuyAddCart.js


const handleBuyAndAddtoCart = (e, form, cart, { id , name , image , id_color , name_color , filtro , costo , codigo , descuento , sizes  })=>{
    e.preventDefault();
    form = form.current;
    if (cart.find((p)=>p.id === id) && cart.find((p)=>p.size.id === form[0].value)) return;
    const product = {
        id,
        idDelete: Math.floor(Math.random() * 1000000000),
        code: codigo,
        name: name,
        image: image[0],
        color: {
            id: id_color,
            name: name_color
        },
        size: {
            id: form[0].value,
            name: form[0].options[form[0].selectedIndex].text
        },
        quantity: 1,
        sex: filtro.sex.name,
        linea: filtro.linea.name,
        categoria: filtro.categoria.name,
        marca: filtro.marca.name,
        costo: costo - descuento
    };
    store/* default.dispatch */.Z.dispatch((0,actionCreators/* addToCart */.Xq)(product));
};

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "nprogress"
var external_nprogress_ = __webpack_require__(808);
var external_nprogress_default = /*#__PURE__*/__webpack_require__.n(external_nprogress_);
;// CONCATENATED MODULE: ./component/hook/usePageProduct.js

//cambia el modelo
const changueModel = (codeCurrent, code, idDad, router)=>{
    if (code === codeCurrent) return;
    router.push(`/articulo/${idDad}/${code}`);
};
//cambia la imagen de la galeria
const handleChangeImgGallery = (action, images, setImage, position, setPosition)=>{
    external_nprogress_default().start();
    switch(action){
        case "next":
            if (position < images.length - 1) {
                setPosition(position + 1);
                setImage(images[position + 1]);
            } else {
                setPosition(0);
                setImage(images[0]);
            }
            break;
        case "back":
            if (position > 0) {
                setPosition(position - 1);
                setImage(images[position - 1]);
            } else {
                setPosition(images.length - 1);
                setImage(images[images.length - 1]);
            }
        default:
            break;
    }
};

;// CONCATENATED MODULE: ./component/molecules/Gallery.jsx





const galery = /*#__PURE__*/ (0,external_react_.createRef)();
const Gallery = ({ images , name  })=>{
    const { 0: image , 1: setImage  } = (0,external_react_.useState)(images[0]);
    const { 0: position , 1: setPosition  } = (0,external_react_.useState)(0);
    const { 0: animate , 1: setAnimate  } = (0,external_react_.useState)("animate");
    (0,external_react_.useEffect)(()=>{
        setImage(images[0]);
        setPosition(0);
    }, [
        name,
        images
    ]);
    const nextImage = ()=>{
        handleChangeImgGallery("next", images, setImage, position, setPosition);
    };
    const backImage = ()=>{
        handleChangeImgGallery("back", images, setImage, position, setPosition);
    };
    const delteAnimateLoad = ()=>{
        setAnimate("");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `gallery-sale ${animate}`,
        ref: galery,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                layout: "fill",
                src: image,
                alt: name,
                priority: true,
                onLoadingComplete: delteAnimateLoad,
                onLoad: ()=>external_nprogress_default().done()
            }),
            images.length == 1 ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "btn-galeria",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "btn-gallery gallery-back",
                            onClick: backImage
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "btn-gallery gallery-next",
                            onClick: nextImage
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const molecules_Gallery = (Gallery);

// EXTERNAL MODULE: ./component/atoms/Like.jsx
var Like = __webpack_require__(925);
;// CONCATENATED MODULE: ./component/molecules/Share.jsx


const inputUrl = /*#__PURE__*/ (/* unused pure expression or super */ null && (createRef()));
const Share = ({ children , urlWeb  })=>{
    const copiUrl = (event)=>{
        event.preventDefault();
        const link = urlWeb;
        navigator.clipboard.writeText(link);
        alert("enlace copiadoaa");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "box-share",
        children: [
            children ? children : /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: `https://api.whatsapp.com/send?text=Mira%20este%20fabuloso%20articulo%20${urlWeb}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "link-share",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "img-share",
                    src: "/images/ico_whatsapp.svg",
                    title: "Compartir en whatsapp",
                    alt: "whatsapp"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: `https://www.facebook.com/sharer/sharer.php?u=${urlWeb}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "link-share",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "img-share",
                    src: "/images/ico_face.svg",
                    title: "Compartir en facebook",
                    alt: "facebook"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: `https://twitter.com/intent/tweet?text=Mira%20este%20fabuloso%20articulo%20&url=${urlWeb}`,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "link-share",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "img-share",
                    src: "/images/ico_twitter.svg",
                    title: "Compartir en twitter",
                    alt: "twitter"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                onClick: copiUrl,
                className: "link-share",
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "img-share",
                    src: "/images/ico_copy.svg",
                    alt: "copy",
                    title: "Copiar enlace al portapapeles"
                })
            })
        ]
    });
};
/* harmony default export */ const molecules_Share = (Share);

// EXTERNAL MODULE: ./component/molecules/Help.jsx
var Help = __webpack_require__(9199);
// EXTERNAL MODULE: ./component/molecules/PaymentTypeImage.jsx
var PaymentTypeImage = __webpack_require__(135);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./component/atoms/ButtonBack.jsx
var ButtonBack = __webpack_require__(9161);
;// CONCATENATED MODULE: ./component/template/PageProduct.jsx















const PageProduct = ({ product , models , cart , idDad , deleteCart , typeUser , currentModel  })=>{
    const router = (0,router_.useRouter)();
    const formulary = (0,external_react_.useRef)();
    const { 0: urlWeb , 1: seturlWeb  } = (0,external_react_.useState)("");
    (0,external_react_.useEffect)(()=>{
        seturlWeb(window.location.href);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "nav-product-sale",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(ButtonBack/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(molecules_Share, {
                        urlWeb: urlWeb,
                        children: typeUser != 1 ? /*#__PURE__*/ jsx_runtime_.jsx(Like/* default */.Z, {
                            css: "img-share",
                            idDad: idDad,
                            id: product.id,
                            name: product.name,
                            cost: product.costo,
                            image: product.image[0],
                            codigo: product.codigo,
                            descuento: product.descuento
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(molecules_Gallery, {
                images: product.image,
                name: product.name
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card-sale",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: product.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "box-price",
                        children: product.descuento > 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "box-price-cart-ofert",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "price-cart price-cart-ofert",
                                        children: [
                                            "S/ ",
                                            product.costo,
                                            ",",
                                            /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                                children: "00"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "price-cart",
                                    children: [
                                        "S/ ",
                                        product.costo - product.descuento,
                                        ",",
                                        /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                            children: "00"
                                        })
                                    ]
                                })
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "price-cart",
                            children: [
                                "S/ ",
                                product.costo,
                                ",",
                                /*#__PURE__*/ jsx_runtime_.jsx("b", {
                                    children: "00"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                        className: "from-sale-product",
                        onSubmit: (e)=>{
                            handleBuyAndAddtoCart(e, formulary, cart, product);
                            router.push("/compra/carrito");
                        },
                        ref: formulary,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                className: "label",
                                children: "ELIGE EL COLOR DE TU PREFERENCIA"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "box_image_select_color",
                                children: models.map((m, i)=>m.codigo === product.codigo ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: " image_selecet_model model_image_active",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            width: 60,
                                            height: 50,
                                            objectFit: "contain",
                                            onClick: ()=>changueModel(product.codigo, m.codigo, idDad, router),
                                            src: m.image,
                                            alt: m.codigo
                                        }, i)
                                    }, m.codigo) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: " image_selecet_model",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            width: 60,
                                            height: 50,
                                            objectFit: "contain",
                                            onClick: ()=>changueModel(product.codigo, m.codigo, idDad, router),
                                            src: m.image,
                                            alt: m.codigo
                                        }, i)
                                    }, m.codigo))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                children: "ELIGE TU TALLA"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("select", {
                                name: "talla",
                                children: product.sizes.map((s)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                        value: s.id,
                                        children: s.name
                                    }, s.id))
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "submit",
                                className: "button",
                                children: "COMPRAR"
                            }),
                            cart.find((c)=>c.id === product.id) ? /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                onClick: ()=>deleteCart(product.id),
                                className: "button button-ghost",
                                children: "BORRAR DEL CARRITO"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "button button-ghost",
                                onClick: (e)=>handleBuyAndAddtoCart(e, formulary, cart, product),
                                children: "AGREGAR AL CARRITO"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    product.descripcion != "" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                children: "Descripci\xf3n"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "product-description",
                                children: product.descripcion
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: product.caracteristicas != "" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                    children: "Car\xe1cteristicas"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                                    className: "list-features",
                                    children: product.caracteristicas.split(",").map((t)=>t.trim().toLowerCase()).map((t, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                " ",
                                                t,
                                                " "
                                            ]
                                        }, i))
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "product-page-help",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Help/* default */.Z, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(PaymentTypeImage/* default */.Z, {})
                ]
            })
        ]
    });
};
const mapStateToProps = (state)=>({
        cart: state.carritoReducer.products,
        typeUser: state.userReducer.type
    });
const mapDispatchToProps = (dispatch)=>({
        deleteCart (id) {
            dispatch((0,actionCreators/* removeFromCart */.h2)({
                id
            }));
        }
    });
/* harmony default export */ const template_PageProduct = ((0,external_react_redux_.connect)(mapStateToProps, mapDispatchToProps)(PageProduct));

// EXTERNAL MODULE: ./component/hook/Ajax.js
var Ajax = __webpack_require__(3070);
// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(6641);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./component/hook/useQuery.js
var useQuery = __webpack_require__(1826);
// EXTERNAL MODULE: ./component/CardProduct.jsx + 1 modules
var CardProduct = __webpack_require__(2758);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/articulo/[...slug].jsx












const Product = ({ product , idDad , currentModel , models  })=>{
    const router = (0,router_.useRouter)();
    const { 0: productosDestacados , 1: setProductosDestacados  } = (0,external_react_.useState)([]);
    {
        console.log(router.query.slug);
    }
    (0,external_react_.useEffect)(()=>{
        (0,useQuery/* destacados */.U3)(setProductosDestacados);
    }, []);
    if (!product) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mw-grid separador"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                    className: "mw-grid",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "alert alert-yellow",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "Ha consultado un producto agotado por el momento \xf3 que no existe."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/productos/todos",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: " Ver todos los productos"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "t2 title-gird-productos",
                            children: "Productos Destacados"
                        }),
                        productosDestacados.length == 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "alert alert-blue",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Cargando productos destacados... "
                            })
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid-products",
                            children: [
                                console.log("productos destacados"),
                                productosDestacados.map((familyProduct)=>familyProduct.map((p, i)=>{
                                        if (p.es_padre) return /*#__PURE__*/ jsx_runtime_.jsx(CardProduct/* default */.Z, {
                                            code: p.codigo,
                                            id: p.id,
                                            idDad: p.id,
                                            name: p.name,
                                            costo: p.costo,
                                            descuento: p.descuento,
                                            image: p.image[0],
                                            familyProduct: familyProduct
                                        }, i);
                                    }))
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mw-grid separador"
                })
            ]
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_next_seo_.NextSeo, {
                title: `${"FABIAN SPORT"} | ${product.name}`,
                description: `${product.descripcion}`,
                openGraph: {
                    title: `${product.name} - S/ ${product.costo - product.descuento}`,
                    description: product.descripcion,
                    type: "article",
                    url: `${"https://fabiansport.com"}/articulo/${idDad}/${currentModel}`,
                    images: [
                        {
                            url: `${product.image[0]}`,
                            width: 998,
                            height: 522,
                            alt: product.name
                        },
                        {
                            url: `${product.image[0]}`,
                            width: 998,
                            height: 522,
                            alt: product.name
                        }
                    ]
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("link", {
                    rel: "canonical",
                    href: `https://fabiansport.com/articulo/${idDad}`
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mw-grid separador"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mw-grid product-view-sale",
                children: /*#__PURE__*/ jsx_runtime_.jsx(template_PageProduct, {
                    product: product,
                    currentModel: currentModel,
                    models: models,
                    idDad: idDad
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mw-grid separador"
            })
        ]
    });
};
async function getServerSideProps({ query  }) {
    let id = query.slug[0], code = query.slug[1], product, models, rsp;
    (0,Ajax/* ajax */.h)(`${"https://fabiansport.com/fs/api"}/clic/${id}`, "PUT");
    rsp = await (0,Ajax/* ajax */.h)(`${"https://fabiansport.com/fs/api"}/producto/${id}`);
    if (rsp.status != 200) return {
        props: {
            product: null
        }
    };
    if (rsp.data.id) rsp = await (0,Ajax/* ajax */.h)(`${"https://fabiansport.com/fs/api"}/producto/${rsp.data.id}`);
    if (code) {
        product = rsp.data.find((product)=>product.codigo === code);
        if (!product) product = rsp.data[0];
    } else product = rsp.data[0];
    models = rsp.data.map((model)=>({
            codigo: model.codigo,
            id_color: model.id_color,
            name_color: model.name_color,
            image: model.image[0]
        }));
    return {
        props: {
            models,
            product,
            currentModel: code || product.codigo,
            idDad: query.slug[0]
        }
    };
}
/* harmony default export */ const _slug_ = (Product);


/***/ }),

/***/ 6807:
/***/ ((module) => {

module.exports = require("@redux-devtools/extension");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

module.exports = require("nprogress");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("redux");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9311,910,2952,1664,5675,3077,8406,3070,3619,2196,1826,925,9199,826], () => (__webpack_exec__(4243)));
module.exports = __webpack_exports__;

})();