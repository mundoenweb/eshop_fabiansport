(() => {
var exports = {};
exports.id = 5490;
exports.ids = [5490];
exports.modules = {

/***/ 3098:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3098));
module.exports = __webpack_exports__;

})();